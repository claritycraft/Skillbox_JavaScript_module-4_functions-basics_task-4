let count = 3;

function isCountPlusOne() {
  count++;
  // count += 1
  console.log(count);
}

isCountPlusOne();
isCountPlusOne();
